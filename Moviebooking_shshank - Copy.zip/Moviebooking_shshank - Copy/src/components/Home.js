import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';
import standard from '../components/standard.jpeg';
import deluxe from '../components/delexue.jpeg';
import suite from '../components/suite.jpeg';
import spain from '../components/spain.jpg'; 
import london from '../components/london.jpg';
import croatia from '../components/croatia.jpg'; 
import germany from '../components/germany.jpeg';
import france from '../components/france.jpeg'; 
import italy from '../components/italy.jpeg';
import swiss from '../components/swiss.jpeg';
import india from '../components/india.jpeg';
import japan from '../components/japan.jpeg'; 

import react from 'react';
const ProductListComponent=({})

// Sample data for rooms
const rooms = [
  {
    id: 1,
    name: 'Standard Seat',
    description: 'A cozy seat with essential amenities.',
    price: '$20',
    image: standard
  },
  {
    id: 2,
    name: 'Deluxe Seat',
    description: 'A spacious seat with premium amenities.',
    price: '$50',
    image: deluxe
  },
  {
    id: 3,
    name: 'Recliner',
    description: 'Luxurious seats with extra space and high-end amenities.',
    price: '$70',
    image: suite
  },

];


// Sample data for popular destinations
const destinations = [
  {
    id: 1,
    name: 'F1',
    image: spain,
  },
  {
    id: 2,
    name: 'Deadpool & Wolverine',
    image: london,
  },
  {
    id: 3,
    name: 'Mufasa-The Lion King',
    image: croatia,
  },
  {
    id: 4,
    name: 'Captain America: Brave New World',
    image: germany,
  },
  {
    id: 5,
    name: 'Joker: Folie à Deux',
    image: france,
  },
  {
    id: 6,
    name: 'The Fall Guy',
    image: italy,
  },
  {
    id: 7,
    name: 'Hit Man',
    image: swiss,
  },
  {
    id: 8,
    name: 'Godzilla x Kong: The New Empire',
    image: india,
  },
  {
    id: 9,
    name: 'Transformers ONE',
    image: japan,
  },
  
];

const Home = () => {
  const navigate = useNavigate();

  const handleBookRoom = (roomId) => {
    navigate(`/payment/${roomId}`);
  };

  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Book your MOVIE TICKETS with Us</h1>
        <p>Endless Entertainment Anytime. Anywhere!</p>
        <div className="booking-options">
          <input type="text" placeholder="Search For Movies" />
          <input type="date" placeholder="Book" />
          <input type="dropdown" placeholder="Location" />
          <input type="number" placeholder="How Many Seats?" min="1" />
          <button className="search-button">Search</button>
        </div>
      </header>

      <section className="popular-destinations">
        <h2>Popular Movies</h2>
        <div className="destination-list">
          {destinations.map((destination) => (
            <div key={destination.id} className="destination-card">
              <img src={destination.image} alt={destination.name} className="destination-image" />
              <h3>{destination.name}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="room-options">
        <h2>Book</h2>
        <div className="room-list">
          {rooms.map((room) => (
            <div key={room.id} className="room-card">
              <img src={room.image} alt={room.name} className="room-image" />
              <h3>{room.name}</h3>
              <p>{room.description}</p>
              <p className="room-price">{room.price}</p>
              <button className="book-room-button" onClick={() => handleBookRoom(room.id)}>Book Seat</button>
            </div>
          ))}
        </div>
      </section>

      <section className="testimonials">
        <h2>What Our Users Say</h2>
        <div className="testimonial-list">
          <div className="testimonial">
            <p>"Amazing experience! The seat was clean and comfortable, and the service was top-notch."</p>
            <p>- VANSHIKA SHARMA</p>
          </div>
          <div className="testimonial">
            <p>"Highly recommend!"</p>
            <p>- Jane Smith</p>
          </div>
          <div className="testimonial">
            <p>"Amazing Experience!!!!!!!!!!!"</p>
            <p>- Emily Johnson</p>
          </div>
        </div>
      </section>

      <section className="contact-us">
        <h2>Contact Us</h2>
        <p>Have questions? Reach out to our customer support team 24/7 via phone or email.</p>
      </section>

      <footer className="site-footer">
        <p>&copy; 2024 SD LTD. All Rights Reserved.</p>
        <p>Follow us on:</p>
        <div className="social-media-icons">
          <a href="https://facebook.com">Facebook</a> | 
          <a href="https://twitter.com">Twitter</a> | 
          <a href="https://instagram.com">Instagram</a>
        </div>
      </footer>
    </div>
  );
};

export default Home;
